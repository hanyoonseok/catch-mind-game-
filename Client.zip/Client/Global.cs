﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Client
{
	public static class Global
	{
		public static NetworkStream stream;
		public static Form2 frm2;
	}
}
