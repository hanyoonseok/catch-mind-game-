﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Server
{
    public partial class Form2 : System.Windows.Forms.Form
    {

        public Form2()
        {
            InitializeComponent();
            
        }

    }
}
